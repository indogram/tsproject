# How to install
In linux/git-bash windows:<br/>

* git clone https://github.com/jrxuii/igbotmay.git
* cd igbotmay
* unzip node_modules.zip
